-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 27 Feb 2024 pada 15.23
-- Versi server: 10.4.28-MariaDB
-- Versi PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_restoran1`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `detail_transaksi`
--

CREATE TABLE `detail_transaksi` (
  `id_detail_transaksi` int(11) NOT NULL,
  `id_transaksi` varchar(11) NOT NULL,
  `id_menu` varchar(11) NOT NULL,
  `harga` int(11) NOT NULL,
  `jumlah` int(11) NOT NULL,
  `total_harga` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `detail_transaksi`
--

INSERT INTO `detail_transaksi` (`id_detail_transaksi`, `id_transaksi`, `id_menu`, `harga`, `jumlah`, `total_harga`) VALUES
(1, 'TR001', 'MN003', 10000, 1, 10000),
(2, 'TR002', 'MN002', 15000, 2, 30000),
(3, 'TR003', 'MN002', 15000, 1, 15000),
(4, 'TR003', 'MN004', 12000, 1, 12000),
(5, 'TR004', 'MN001', 15000, 9, 135000);

--
-- Trigger `detail_transaksi`
--
DELIMITER $$
CREATE TRIGGER `kurangi_stok` AFTER INSERT ON `detail_transaksi` FOR EACH ROW BEGIN
UPDATE menu SET stok = stok - NEW.jumlah
WHERE id_menu = NEW.id_menu;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `log_aktivitas`
--

CREATE TABLE `log_aktivitas` (
  `id_log` int(11) NOT NULL,
  `id_pegawai` varchar(11) NOT NULL,
  `aktifitas` varchar(100) NOT NULL,
  `waktu` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `log_aktivitas`
--

INSERT INTO `log_aktivitas` (`id_log`, `id_pegawai`, `aktifitas`, `waktu`) VALUES
(1, 'PG002', 'Kasir melakukan transaksi', '2024-02-27 12:07:05'),
(2, 'PG003', 'Data menu berhasil dirubah', '2024-02-27 12:07:06'),
(3, 'PG002', 'Kasir melakukan transaksi', '2024-02-27 12:07:06'),
(4, 'PG003', 'Data menu berhasil dirubah', '2024-02-27 12:07:06'),
(54, 'PG002', 'Kasir melakukan transaksi', '2024-02-27 14:20:09'),
(55, 'PG003', 'Data meja berhasil dirubah', '2024-02-27 14:20:09'),
(56, 'PG003', 'Data menu berhasil dirubah', '2024-02-27 14:20:09');

-- --------------------------------------------------------

--
-- Struktur dari tabel `meja`
--

CREATE TABLE `meja` (
  `id_meja` varchar(10) NOT NULL,
  `no_meja` int(11) NOT NULL,
  `jenis_meja` enum('single','double','family','exclusif') NOT NULL,
  `jml_kursi` int(11) NOT NULL,
  `status` enum('1','0') NOT NULL,
  `id_pegawai` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `meja`
--

INSERT INTO `meja` (`id_meja`, `no_meja`, `jenis_meja`, `jml_kursi`, `status`, `id_pegawai`) VALUES
('MJ001', 1, 'single', 2, '1', 'PG004'),
('MJ002', 2, 'double', 4, '1', 'PG003'),
('MJ003', 3, 'family', 6, '0', 'PG003'),
('MJ004', 4, 'single', 1, '0', 'PG003'),
('MJ005', 5, 'double', 8, '1', 'PG003'),
('MJ006', 6, 'family', 10, '0', 'PG003');

--
-- Trigger `meja`
--
DELIMITER $$
CREATE TRIGGER `edit_meja` AFTER UPDATE ON `meja` FOR EACH ROW BEGIN
INSERT INTO log_aktivitas (id_pegawai, aktifitas) VALUES
(NEW.id_pegawai, "Data meja berhasil dirubah");
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `hapus_meja` AFTER DELETE ON `meja` FOR EACH ROW BEGIN
INSERT INTO log_aktivitas (id_pegawai, aktifitas) VALUES
(OLD.id_pegawai, "Manager menghapus data meja");
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `tambah_meja` AFTER INSERT ON `meja` FOR EACH ROW BEGIN
INSERT INTO log_aktivitas (id_pegawai, aktifitas) VALUES
(NEW.id_pegawai, "Manager menambah data meja");
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `menu`
--

CREATE TABLE `menu` (
  `id_menu` varchar(11) NOT NULL,
  `nama_menu` varchar(30) NOT NULL,
  `jenis` enum('Makanan','Minuman') NOT NULL,
  `harga` int(11) NOT NULL,
  `stok` int(11) NOT NULL,
  `id_pegawai` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `menu`
--

INSERT INTO `menu` (`id_menu`, `nama_menu`, `jenis`, `harga`, `stok`, `id_pegawai`) VALUES
('MN001', 'Ayam', 'Makanan', 15000, 40, 'PG003'),
('MN002', 'Ayam Geprek', 'Makanan', 15000, 47, 'PG003'),
('MN003', 'Es Teh', 'Minuman', 10000, 49, 'PG003'),
('MN004', 'Es Jeruk', 'Minuman', 12000, 49, 'PG003'),
('MN005', 'Kentang Goreng', 'Makanan', 10000, 50, 'PG003');

--
-- Trigger `menu`
--
DELIMITER $$
CREATE TRIGGER `edit_menu` AFTER UPDATE ON `menu` FOR EACH ROW BEGIN
INSERT INTO log_aktivitas (id_pegawai, aktifitas) VALUES
(NEW.id_pegawai, "Data menu berhasil dirubah");
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `hapus_menu` AFTER DELETE ON `menu` FOR EACH ROW BEGIN
INSERT INTO log_aktivitas (id_pegawai, aktifitas) VALUES
(OLD.id_pegawai, "Manager menghapus data menu");
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `tambah_menu` AFTER INSERT ON `menu` FOR EACH ROW BEGIN
INSERT INTO log_aktivitas (id_pegawai, aktifitas) VALUES
(NEW.id_pegawai, "Manager menambahkan data menu");
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pegawai`
--

CREATE TABLE `pegawai` (
  `id_pegawai` varchar(11) NOT NULL,
  `nama_pegawai` varchar(30) NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `jenis` enum('admin','kasir','manager') NOT NULL,
  `no_hp` varchar(11) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pegawai`
--

INSERT INTO `pegawai` (`id_pegawai`, `nama_pegawai`, `jenis_kelamin`, `jenis`, `no_hp`, `alamat`) VALUES
('PG001', 'Olivia', 'P', 'admin', '08912345678', 'Kuningan'),
('PG002', 'Dona', 'P', 'kasir', '03241567895', 'Jalaksana'),
('PG003', 'Dito', 'L', 'manager', '09876543219', 'Cijoho'),
('PG004', 'Radit', 'L', 'kasir', '07896567389', 'Cigugur');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` varchar(11) NOT NULL,
  `nama_pelanggan` varchar(30) NOT NULL,
  `jenis_kelamin` enum('L','P') NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `alamat` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `nama_pelanggan`, `jenis_kelamin`, `no_hp`, `alamat`) VALUES
('PN001', 'Aditya', 'L', '0867564324', 'kuningan'),
('PN002', 'Radit', 'L', '0987657896', 'Cijoho'),
('PN003', 'Zizi', 'P', '0798589325', 'Ciporang');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengguna`
--

CREATE TABLE `pengguna` (
  `username` varchar(30) NOT NULL,
  `password` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `jenis` enum('admin','kasir','manager') NOT NULL,
  `id_pegawai` varchar(5) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `update_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `active` enum('1','0') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pengguna`
--

INSERT INTO `pengguna` (`username`, `password`, `email`, `jenis`, `id_pegawai`, `created_at`, `update_at`, `active`) VALUES
('dito', 'dito123', 'dito@gmail.com', 'manager', 'PG003', '2024-02-27 03:00:14', '2024-02-27 03:00:14', '1'),
('dona', 'dona123', 'dona@gmail.com', 'kasir', 'PG002', '2024-02-27 02:44:58', '2024-02-27 02:44:37', '1'),
('olivia', 'olivia123', 'olivia@gmail.com', 'admin', 'PG001', '2024-02-27 11:50:36', '2024-02-27 02:43:08', '1'),
('radit', 'radit123', 'radit@gmail.com', 'kasir', 'PG004', '2024-02-27 12:14:39', '2024-02-27 12:04:10', '1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `transaksi`
--

CREATE TABLE `transaksi` (
  `id_transaksi` varchar(11) NOT NULL,
  `tanggal` date NOT NULL,
  `id_pegawai` varchar(11) NOT NULL,
  `id_pelanggan` varchar(11) NOT NULL,
  `id_meja` varchar(11) NOT NULL,
  `subtotal` int(11) NOT NULL,
  `total` int(11) NOT NULL,
  `bayar` int(11) NOT NULL,
  `kembali` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `transaksi`
--

INSERT INTO `transaksi` (`id_transaksi`, `tanggal`, `id_pegawai`, `id_pelanggan`, `id_meja`, `subtotal`, `total`, `bayar`, `kembali`) VALUES
('TR001', '2024-02-27', 'PG002', 'PN001', 'MJ001', 10000, 10000, 20000, 10000),
('TR002', '2024-02-27', 'PG002', 'PN001', 'MJ001', 30000, 30000, 50000, 20000),
('TR003', '2024-02-27', 'PG004', 'PN003', 'MJ002', 12000, 27000, 30000, 3000),
('TR004', '2024-02-27', 'PG002', 'PN003', 'MJ005', 135000, 135000, 150000, 15000);

--
-- Trigger `transaksi`
--
DELIMITER $$
CREATE TRIGGER `log_kasir` AFTER INSERT ON `transaksi` FOR EACH ROW BEGIN
INSERT INTO log_aktivitas (id_pegawai, aktifitas) VALUES
(NEW.id_pegawai, "Kasir melakukan transaksi");
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_meja` AFTER INSERT ON `transaksi` FOR EACH ROW BEGIN
UPDATE meja SET status = "1" WHERE id_meja = 
NEW.id_meja;
END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `detail_transaksi`
--
ALTER TABLE `detail_transaksi`
  ADD PRIMARY KEY (`id_detail_transaksi`),
  ADD KEY `id_transaksi` (`id_transaksi`),
  ADD KEY `id_menu` (`id_menu`);

--
-- Indeks untuk tabel `log_aktivitas`
--
ALTER TABLE `log_aktivitas`
  ADD PRIMARY KEY (`id_log`),
  ADD KEY `id_pegawai` (`id_pegawai`);

--
-- Indeks untuk tabel `meja`
--
ALTER TABLE `meja`
  ADD PRIMARY KEY (`id_meja`),
  ADD KEY `no_meja` (`no_meja`);

--
-- Indeks untuk tabel `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id_menu`),
  ADD KEY `nama_menu` (`nama_menu`);

--
-- Indeks untuk tabel `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`id_pegawai`),
  ADD KEY `no_hp` (`no_hp`);

--
-- Indeks untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`),
  ADD KEY `no_hp` (`no_hp`);

--
-- Indeks untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  ADD PRIMARY KEY (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `id_pegawai` (`id_pegawai`);

--
-- Indeks untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD PRIMARY KEY (`id_transaksi`),
  ADD KEY `subtotal` (`subtotal`,`total`,`bayar`,`kembali`),
  ADD KEY `id_pegawai` (`id_pegawai`,`id_pelanggan`,`id_meja`),
  ADD KEY `id_meja` (`id_meja`),
  ADD KEY `id_pelanggan` (`id_pelanggan`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `detail_transaksi`
--
ALTER TABLE `detail_transaksi`
  MODIFY `id_detail_transaksi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT untuk tabel `log_aktivitas`
--
ALTER TABLE `log_aktivitas`
  MODIFY `id_log` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `detail_transaksi`
--
ALTER TABLE `detail_transaksi`
  ADD CONSTRAINT `detail_transaksi_ibfk_1` FOREIGN KEY (`id_transaksi`) REFERENCES `transaksi` (`id_transaksi`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `detail_transaksi_ibfk_2` FOREIGN KEY (`id_menu`) REFERENCES `menu` (`id_menu`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `pengguna`
--
ALTER TABLE `pengguna`
  ADD CONSTRAINT `pengguna_ibfk_1` FOREIGN KEY (`id_pegawai`) REFERENCES `pegawai` (`id_pegawai`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `transaksi`
--
ALTER TABLE `transaksi`
  ADD CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`id_meja`) REFERENCES `meja` (`id_meja`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `transaksi_ibfk_2` FOREIGN KEY (`id_pelanggan`) REFERENCES `pelanggan` (`id_pelanggan`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
